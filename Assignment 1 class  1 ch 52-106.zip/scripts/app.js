function hello(){
    console.log("hello there");
}

function main(){
    hello();
    console.log("Hello im the main");
}

window.onload = main;